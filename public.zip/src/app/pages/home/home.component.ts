import { Component, Inject, inject, PLATFORM_ID } from '@angular/core';
import { Router } from '@angular/router';
import { SharedDataService } from '../../../service/shared-data.service';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {
  isBrowser: boolean = false

  constructor(@Inject(PLATFORM_ID) private platformId: Object){

  }

  ngOnInit(){
    this.isBrowser = isPlatformBrowser(this.platformId);
    if (this.isBrowser) {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }
  }

  router = inject(Router);
  navigationService = inject(SharedDataService);

  navigateToContact() {
    this.navigationService.setActiveLink('/contact-us');
    this.router.navigateByUrl('/contact-us');
  }
}
