import { Component, Inject, PLATFORM_ID, } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators, AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { CommonModule, isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-contact-us',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './contact-us.component.html',
  styleUrl: './contact-us.component.scss',
})
export class ContactUsComponent {
  contactForm: FormGroup;
  isBrowser: boolean = false

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {
    
    this.contactForm = new FormGroup({
      fullName: new FormControl(''),
      email: new FormControl('', [
        Validators.required,
        Validators.email,
        this.functiocustomEmailValidator(),
      ]),
      contactNo: new FormControl('', [
        this.contactNumberValidator(),
      ]),
      websiteUrl: new FormControl('', [
        Validators.required,
        this.websiteUrlValidator(),
      ]),
      sourceMedium: new FormControl('', [
        Validators.required,
      ]),
      message: new FormControl(),
    });
  }

  ngOnInit(){
    this.isBrowser = isPlatformBrowser(this.platformId);
    if (this.isBrowser) {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }
  }

  functiocustomEmailValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const emailPattern =
        /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,})$/;
      const value = control.value;
      if (!value) {
        return null;
      }
      const isValid = emailPattern.test(value);
      return isValid ? null : { invalidEmail: true };
    };
  }

  isemailInvalid() {
    if (
      this.contactForm.get('email')?.invalid &&
      this.contactForm.get('email')?.touched
    ) {
      return (
        this.contactForm.get('email')?.errors?.['required'] ||
        this.contactForm.get('email')?.errors?.['invalidEmail']
      );
    } else {
      return false;
    }
  }

  contactNumberValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const value = control.value;
      if (!value) {
        return null; // It's optional, so if it's empty, it's valid
      }
      const isValid = /^\d{10}$/.test(value);
      return isValid ? null : { invalidContactNumber: true };
    };
  }

  isContactNumberInvalid() {
    return this.contactForm.get('contactNo')?.invalid && this.contactForm.get('contactNo')?.touched;
  }

  websiteUrlValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const urlPattern = /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
      const value = control.value;
      if (!value) {
        return null;
      }
      const isValid = urlPattern.test(value);
      return isValid ? null : { invalidUrl: true };
    };
  }

  isWebsiteInvalid() {
    return this.contactForm.get('websiteUrl')?.invalid && this.contactForm.get('websiteUrl')?.touched;
  }

  isSourceMediumInvalid() {
    return this.contactForm.get('sourceMedium')?.invalid && this.contactForm.get('sourceMedium')?.touched;
  }

  submit(){
    console.log('hi')
    alert('Response sent successfully. Wait to hear back from us')
    this.contactForm.reset()
  }
  
}
